# laravel-favicon-animado

Componentes Blade para favicon animado e barra de ouvidoria.

## Instalação

Veja o README para instruções de uso.
